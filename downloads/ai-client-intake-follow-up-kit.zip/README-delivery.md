# Delivery Instructions — AI Client Intake & Follow-Up Kit

## Customer delivery
After purchase, send the customer the file:

- `products/ai-client-intake-follow-up-kit.md`

Recommended delivery copy:

Subject: Your AI Client Intake & Follow-Up Kit

Hi,

Thanks for your purchase. Your kit is attached/included below. You can copy the templates into your form tool, notes app, CRM, or AI workspace and customize them for your business.

Start with the implementation SOP at the bottom of the kit, then customize the intake questionnaire and email snippets.

Best,
OpsKit AI

## Product link
Stripe checkout:
https://buy.stripe.com/3cI7sE9F79Vxfu12kX1wY00

## Fulfillment gap
If Stripe automatic file delivery is not configured, fulfillment may require manual handling or a no-code download page in a future cycle.