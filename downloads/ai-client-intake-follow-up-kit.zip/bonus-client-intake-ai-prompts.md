# Bonus: Client Intake AI Prompt Library

Use these prompts with the AI tool of your choice. Paste real client details only if you are allowed to do so and avoid sensitive/confidential information unless your tool and agreement support it.

## 1. Lead qualification summary
You are helping me qualify a potential service client. Summarize the intake below into:
- Business goal
- Urgency
- Budget/timeline clarity
- Decision-maker clarity
- Scope risk
- Best next question
- Fit score from 1–5 with reasoning

Intake:
[paste intake]

## 2. Missing information finder
Review this intake and identify what is missing before I can create a responsible proposal. Group missing details into: goals, stakeholders, technical/access needs, budget, timeline, risks, and approvals.

Intake:
[paste intake]

## 3. Discovery call agenda
Create a 30-minute discovery call agenda based on this intake. Keep it consultative and practical. Include timing, key questions, and what I should confirm before the call ends.

Intake:
[paste intake]

## 4. Call notes cleaner
Turn these rough discovery call notes into a clean internal brief with: client context, desired outcome, constraints, objections, proposed scope, exclusions, open questions, and recommended next step.

Notes:
[paste notes]

## 5. Follow-up email from notes
Draft a concise follow-up email from these call notes. It should be professional, warm, honest, and clear about next steps. Do not overpromise.

Notes:
[paste notes]

## 6. Proposal scope draft
Create a proposal scope draft from these details. Include: objective, deliverables, not included, timeline, client responsibilities, assumptions, risks, and next step.

Details:
[paste details]

## 7. Objection response helper
Given the client objection below, draft a calm, helpful response. Do not pressure the client. Clarify tradeoffs and suggest a next step.

Objection:
[paste objection]

Project context:
[paste context]

## 8. Proposal simplifier
Rewrite this proposal section so it is clearer, more specific, and easier for a non-technical client to understand. Preserve the meaning and do not add claims.

Proposal section:
[paste text]

## 9. Scope creep boundary email
Draft a polite email explaining that the requested item is outside the agreed scope. Offer two options: defer it to a later phase or add it as a paid change.

Context:
[paste context]

## 10. Lost lead learning prompt
A lead did not move forward. Based on the notes below, identify likely reasons, lessons for next time, and one improvement to the intake process.

Notes:
[paste notes]
