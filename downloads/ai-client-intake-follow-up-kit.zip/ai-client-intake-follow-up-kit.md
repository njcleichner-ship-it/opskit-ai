# AI Client Intake & Follow-Up Kit

A practical kit for freelancers, consultants, and small service businesses that want a cleaner way to qualify leads, collect project details, and follow up professionally using AI.

## What is included

1. Client Intake Questionnaire
2. Discovery Call Script
3. Project Scope Clarifier
4. Follow-Up Email Templates
5. AI Prompt Pack
6. Simple Implementation SOP

---

## 1. Client Intake Questionnaire

Use this before a discovery call or proposal.

### Contact basics
- Name:
- Company:
- Email:
- Website/social profile:
- Best way to contact you:

### Project basics
- What are you trying to accomplish?
- What problem triggered this project now?
- What happens if this does not get solved?
- What have you already tried?
- What does success look like 30, 60, and 90 days after completion?

### Scope and constraints
- What deliverables do you think you need?
- Are there examples of work you like?
- Are there examples of work you dislike?
- What deadline are you working toward?
- Is the deadline flexible?
- Who needs to approve the work?
- What budget range have you set aside?

### Fit questions
- Why are you considering outside help instead of doing this internally?
- What would make this engagement feel like a great investment?
- What concerns do you have about hiring someone for this?

---

## 2. Discovery Call Script

### Opening
Thanks for taking the time today. I want to understand what you are trying to accomplish, what is getting in the way, and whether I am the right fit. If I am not, I will say so directly.

### Questions
1. Can you walk me through the current situation?
2. What made this a priority now?
3. What result are you hoping for?
4. What would make this project fail?
5. Who else is involved in the decision?
6. What timeline matters here?
7. What budget range should we design around?
8. Have you worked with someone on this kind of project before?
9. What would you need to see from me to feel confident moving forward?

### Close
Based on what you shared, the next best step is either:
- I send a short proposal with scope, timeline, and price.
- I ask a few follow-up questions first.
- I recommend another route if this is not a fit.

---

## 3. Project Scope Clarifier

Use this after the call to avoid vague proposals.

### Desired outcome
The client wants:

### Deliverables
- Deliverable 1:
- Deliverable 2:
- Deliverable 3:

### Not included
- Item 1:
- Item 2:

### Client responsibilities
- Provide access to:
- Provide feedback within:
- Approve final direction by:

### Timeline
- Kickoff:
- First draft/milestone:
- Revision window:
- Final delivery:

### Risks or dependencies
- Risk 1:
- Risk 2:

---

## 4. Follow-Up Email Templates

### After a good discovery call
Subject: Next steps for [project/outcome]

Hi [Name],

Thanks for speaking with me today. Based on what you shared, the main goal is [goal], with the biggest constraints being [constraint 1] and [constraint 2].

The next step is for me to put together a short proposal covering scope, timeline, and investment. I will send that by [date].

Best,
[Your Name]

### After a call that needs more information
Subject: Quick follow-up questions

Hi [Name],

Thanks again for the conversation. Before I recommend a scope, I want to make sure I understand a few details:

1. [Question]
2. [Question]
3. [Question]

Once I have those, I can suggest the cleanest next step.

Best,
[Your Name]

### After sending a proposal
Subject: Proposal sent — [project/outcome]

Hi [Name],

I just sent over the proposal for [project]. It includes the recommended scope, timeline, price, and what I would need from you to get started.

If it looks good, the next step is [next step]. If you want to adjust scope or timing, reply with what you would like changed and I will revise it.

Best,
[Your Name]

### Polite follow-up after no response
Subject: Checking in on [project]

Hi [Name],

Just checking in to see if [project] is still a priority. If the timing changed, no problem — I am happy to reconnect later.

If you are still interested, the best next step is [next step].

Best,
[Your Name]

---

## 5. AI Prompt Pack

### Summarize an intake form
You are helping me prepare for a discovery call. Summarize this client intake form into: goals, pain points, constraints, likely objections, missing information, and recommended call questions.

Client intake:
[paste intake]

### Turn call notes into next steps
Turn these discovery call notes into: client goal, recommended scope, deliverables, timeline, risks, follow-up questions, and a concise follow-up email.

Call notes:
[paste notes]

### Draft a proposal outline
Create a proposal outline for this project. Keep it clear, honest, and specific. Include outcome, scope, timeline, client responsibilities, price placeholder, and next steps.

Project details:
[paste details]

### Improve a follow-up email
Rewrite this follow-up email to be concise, professional, warm, and low-pressure. Do not exaggerate or add claims.

Email:
[paste email]

---

## 6. Simple Implementation SOP

### One-time setup
1. Copy the intake questionnaire into your form tool, website form, or email template.
2. Save the discovery call script in your notes app.
3. Save the follow-up email templates as snippets.
4. Save the AI prompts in your preferred AI tool.
5. Create a folder for each new lead.

### For every new lead
1. Send the intake questionnaire.
2. Paste the response into the intake summary prompt.
3. Review the generated summary before the call.
4. Run the discovery call using the script as a guide, not a rigid checklist.
5. Paste call notes into the next-steps prompt.
6. Send a follow-up email within 24 hours.
7. If qualified, send a proposal or checkout link.

### Quality control checklist
- Did I understand the business problem?
- Did I confirm the decision-maker?
- Did I clarify budget and timeline?
- Did I define what is not included?
- Did I send the next step in writing?

---

## License
For purchase by one individual or business. You may customize and use internally. Do not resell or redistribute as a standalone template pack.